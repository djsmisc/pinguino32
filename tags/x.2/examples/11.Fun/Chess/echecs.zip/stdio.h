void putchar(unsigned char);
