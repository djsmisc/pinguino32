// Jeux d'ECHECS sur PIC18 C.Dupaty Acad�mie d'Aix-MArseille 03/2004
// Moteur de calcul d'apr�s PROTEUS VSM TINY CHESS http://www.multipower-fr.com/cao/prod01.htm 
// lib io.c 

#include "chess.h"

void RCLF(void) // passage a la ligne sur le terminal 
{
	putsci(10);
	putsci(13);
}

// deux versions de trace_jeux sur le terminal
// avec et sans quadrillage
/*
void trace_jeux(void)
{
char i,j;
	RCLF();
	for (i=7;i>=0;i--)
	{
	for(j=0;j<8;j++)
		{
		switch (board[i][j])
			{
			case 0 : putsci('');break;
			case BLACK|PAWN : putsci('p');break;
			case WHITE|PAWN : putsci('P');break;
			case BLACK|ROOK : putsci('t');break;
			case WHITE|ROOK : putsci('T');break;
			case BLACK|KNIGHT : putsci('c');break;
			case WHITE|KNIGHT : putsci('C');break;
			case BLACK|BISHOP : putsci('f');break;
			case WHITE|BISHOP : putsci('F');break;
			case BLACK|QUEEN : putsci('r');break;
			case WHITE|QUEEN : putsci('R');break;
			case BLACK|KING : putsci('k');break;
			case WHITE|KING : putsci('K');break;
			}
		}
		putsci(' ');
		putsci(i+'1');
		RCLF();
	}
	putrstsci("abcdefgh");
	RCLF();RCLF();
}
*/

// version avec quadrillage
rom char ligne[]=" +-+-+-+-+-+-+-+-+";
void trace_jeux(void)
{
char i,j;
	RCLF();
	putrstsci(ligne);
	RCLF();
	for (i=7;i>=0;i--)
	{
	putsci(' ');
	putsci('|');
	for(j=0;j<8;j++)
		{
		switch (board[i][j])
			{
			case 0 : putsci(' ');break;
			case BLACK|PAWN : putsci('p');break;
			case WHITE|PAWN : putsci('P');break;
			case BLACK|ROOK : putsci('t');break;
			case WHITE|ROOK : putsci('T');break;
			case BLACK|KNIGHT : putsci('c');break;
			case WHITE|KNIGHT : putsci('C');break;
			case BLACK|BISHOP : putsci('f');break;
			case WHITE|BISHOP : putsci('F');break;
			case BLACK|QUEEN : putsci('r');break;
			case WHITE|QUEEN : putsci('R');break;
			case BLACK|KING : putsci('k');break;
			case WHITE|KING : putsci('K');break;
			}
		putsci('|');
		}
		putsci(' ');
		putsci(i+'1');
		RCLF();
		putrstsci(ligne);
	RCLF();
	}
	putrstsci("  a b c d e f g h");
	RCLF();RCLF();
}


BOOL lit_coup_joueur (LOC from, LOC to)
// lit le coup du jour sur USART, retourne vrai a la fin
 { 
	unsigned char key, fdelay, fstate=0;
   	PIECE p;
	unsigned char chaine[6];
   
	 getstsci(chaine,'*'); // recupere le coup jour de la forme e2e4* (* termine la chaine)
	
   // Store the 'from' position
   from[1] = chaine[0]-'a';
   from[0] = chaine[1]-'1';
 
   // Check moving correct piece.

	p = board[from[0]][from[1]];
    if (p == EMPTY || p & BLACK)
		{
			RCLF();
			putrstsci("deplacement interdit !");
			RCLF();
      		return FALSE;
		}
   
   to[1] = chaine[2]-'a';
   to[0] = chaine[3]-'1'; 

   return from[0] != to[0] || from[1] != to[1];
 }
